import os
import numpy as np

os.environ['TF_CPP_MIN_LOG_LEVEL']='2'

# MultiLayer
class MulLayer:
    # 초기화
    def __init__(self):
        self.x = None
        self.y = None

    # 순전파
    def forward(self, x, y):
        self.x = x
        self.y = y
        out = x * y

        return out

    # 역전파
    def backward(self, dout):
        dx = dout * self.y # x 와 y를 바꾼다
        dy = dout * self.x

        return dx, dy


######### 계산 그래프 구현 ( case: 사과를 구매) ######

apple = 100 # 사과가격은 100원
apple_num = 2 # 사과 2개 구매
tax = 1.1 # 부가세 10%

# 계층들
mul_apple_layer = MulLayer()
mul_tax_layer = MulLayer()

# 순전파
apple_price = mul_apple_layer.forward(apple, apple_num) # 사과 구매 갯수 만큼 곱하기
price = mul_tax_layer.forward(apple_price, tax) # 부가세 적용

print(price) # 최종가격 : 220


# 역전파
dprice = 1 # 최종값을 1로 잡고
dapple_price, dtax = mul_tax_layer.backward(dprice)
dapple, dapple_num = mul_apple_layer.backward(dapple_price)

print(dapple, dapple_num, dtax) # 2.2 110 200


######### 계산 그래프 구현 ( case: 사과를 구매) ######


# AddLayer

class AddLayer:
    # 초기화
    def __init__(self):
        pass

    # 순전파
    def forward(self, x, y):
        out = x + y
        return out

    # 역전파
    def backward(self, dout):
        dx = dout * 1
        dy = dout * 1

        return dx, dy



######### addlayer적용 계산 그래프 구현 ( case: 사과, 오렌지를 구매) ######

apple = 100 # 사과가격은 100원
apple_num = 2 # 사과 2개 구매
orange = 150 # 오렌지 가격은 150원
orange_num = 3 # 오렌지 3개 구매
tax = 1.1 # 부가세 10%

# 계층들
mul_apple_layer = MulLayer()
mul_orange_layer = MulLayer()
add_apple_orange = AddLayer()
mul_tax_layer = MulLayer()

# 순전파
apple_price = mul_apple_layer.forward(apple, apple_num) # 사과 구매 갯수 만큼 곱하기
orange_price = mul_orange_layer.forward(orange, orange_num) # 오렌지 구매 갯수 만큼 곱하기
all_price = add_apple_orange.forward(apple_price,orange_price) # 사과 가격 + 오렌지 가격
price = mul_tax_layer.forward(all_price, tax) # 부가세 적용

# 역전파
dprice = 1 # 최종값을 1로 잡고
dall_price, dtax = mul_tax_layer.backward(dprice)
dapple_price, dorange_price = add_apple_orange.backward(dall_price)
dorange, dorange_num = mul_orange_layer.backward(dorange_price)
dapple, dapple_num = mul_apple_layer.backward(dapple_price)

print(price) # 순전파에 의한 최종가격 : 715

print(dapple, dapple_num, dorange, dorange_num, dtax) # 역전파에 의한 초기값 출력


######### addlayer적용 계산 그래프 구현 ( case: 사과, 오렌지를 구매) ######



######### 활성화 함수 구현 #########

# Relu
class Relu:
    # 초기화
    def __init__(self):
        self.mask = None
        # mask : true/flase로 구성된 넘파이 배열 (x의 원소값이 0 이하인 인덱스는 true , 아니면 false)

    # 순전파
    def forward(self, x):
        self.mask = (x<=0)
        out = x.copy()
        out[self.mask] = 0

        return out

    # 역전파
    def backward(self, dout):
        dout[self.mask] = 0
        dx = dout

        return dx

# Sigmoid
class Sigmoid:
    # 초기화
    def __init__(self):
        self.out = None

    # 순전파
    def forward(self, x):
        out = 1 / (1 + np.exp(-x))
        self.out = out

    # 역전파
    def backward(self, dout):
        dx = dout * (1.0 - self.out) * self.out

        return dx


######### 활성화 함수 구현 #########



# Affine Layer : 뉴럴 네트워크에서 표준 레이어
# 신경망의 순전파 때 수행하는 행렬의 곱

class Affine:

    # 초기화
    def __init__(self,W, b):
        self.W = W
        self.b = b
        self.x = None
        self.dW = None
        self.db = None

    # 순전파
    def forward(self, x):
        self.x = x
        out = np.dot(x, self.W)+self.b

        return out

    # 역전파
    def backward(self, dout):
        dx = np.dot(dout, self.W.T)
        self.dW = np.dot(self.x.T, dout)
        self,db = np.sum(dout, axis = 0)

        return dx


# softmax function
def softmax(a):
    c = np.max(a)
    exp_a = np.exp(a - c) #오버플로 대책
    sum_exp_a = np.sum(exp_a)
    y = exp_a / sum_exp_a

    return y

# SoftMaxWithLoss_Layer

# 미니배치용 교차 엔트로피
def cross_entropy_error(y, t):
    if y.ndim == 1:
        t = t.reshape(1, t.size)
        y = y.reshape(1, y.size)

    batch_size = y.shape[0]
    return -np.sum(t * np.log(y + 1e-7))/ batch_size

class SoftmaxWithLoss:

    # 초기화
    def __init__(self):
        self.loss = None # 손실
        self.y = None # softmax의 출력
        self.t = None # 정답 레이블(원-핫 벡터)

    # 순전파
    def forward(self, x, t):
        self.t = t
        self.y = softmax(x)
        self.loss = cross_entropy_error(self.y, self.y)
        return self.loss

    #  역전파
    def backward(self, dout = 1):
        batch_size = self.t.shape[0]
        dx = (self.y - self.t) / batch_size

        return dx










